# Design file
https://www.figma.com/file/XCBWidUFVHNkzrnJ0lDgVR/FOX?type=design&node-id=0%3A1&mode=design&t=dcffZEvqf6JSmD9x-1

# Text
```
Fox

Lorem ipsum dolor sit amet,
consectetuer adipiscing elit. Aenean
commodo ligula eget dolor. Aenean
massa. Cum sociis natoque
penatibus et magnis dis parturient
montes, nascetur ridiculus mus.
Donec quam felis, ultricies nec
```
